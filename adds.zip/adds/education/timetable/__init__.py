# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Timetable Management System
# ----------------------------------------------------------

from . import models
from . import report
