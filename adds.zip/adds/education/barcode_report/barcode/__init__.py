# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

__version__ = '0.9'
