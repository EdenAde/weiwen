# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to BarCode Management System
# ----------------------------------------------------------

from . import report
