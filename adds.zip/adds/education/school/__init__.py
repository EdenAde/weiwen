# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Management System
# ----------------------------------------------------------

from .hooks import post_init_hook
from . import models
from . import wizard
