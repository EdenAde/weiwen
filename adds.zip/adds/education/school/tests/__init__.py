# -*- coding: utf-8 -*-
# See LICENSE file for full copyright and licensing details.

# ----------------------------------------------------------
# A Module to School Management System
# ----------------------------------------------------------
from . import test_school
