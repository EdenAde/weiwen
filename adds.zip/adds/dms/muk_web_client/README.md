# MuK Web Client

Extends the Odoo web client to include channels. Channels can be created to listen to Odoo bus notifications. 