# MuK Web Client Refresh

Adds a refresh channel to the web client. By sending a message to this channel, the corresponding view is reloaded.