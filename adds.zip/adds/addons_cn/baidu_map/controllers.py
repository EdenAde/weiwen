# -*- coding: utf-8 -*-
from openerp import http
