# -*- coding: utf-8 -*-
{
    'name': "replace google map with baidu map",

    'summary': """
        replace google map with baidu map for chinese user""",

    'description': """
         replace google map with baidu map for chinese user
    """,

    'author': 'Odoo CN, Jeffery <jeffery9@gmail.com>',
    'website': "http://www.odoouse.cn",

    'category': 'Uncategorized',
    'version': '0.1',

    'depends': ['base_geolocalize', 'website'],
    'qweb': [],

    'data': ['templates.xml'],

    'price': 4.99,
    'currency': 'EUR',
}
