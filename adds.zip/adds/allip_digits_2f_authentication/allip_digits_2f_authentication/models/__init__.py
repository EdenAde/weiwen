# -*- coding: utf-8 -*-
from . import models
import res_users
import res_partner